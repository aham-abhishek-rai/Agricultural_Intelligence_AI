import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.multioutput import MultiOutputRegressor
from sklearn.preprocessing import LabelEncoder
import pickle

# Predict Cost of Cultivation & Implicit Rate
# -----------------------------
# 1. Load Dataset
# -----------------------------
# Example: Replace with your dataset path
df2 = pd.read_excel("crop_value_cost_data.xlsx")

# 2. Ensure correct data types
# -----------------------------
df2['Year'] = df2['Year'].astype(int)  # Ensure year is integer

df2['Crop'] = df2['Crop'].str.capitalize()
df2.rename(columns={'States':'State'}, inplace = True)
replacements = {'Arhar': 'Arhar/Tur', 'Nigerseed': 'Niger Seed', 'Rapeseed & mustard': 'Rapeseed & Mustard', 'Sesamum': 'Sesamum/Til', \
                'Paddy': 'Rice', 'Moong': 'Mungbean'}

# Apply the replacements
df2['Crop'] = df2['Crop'].replace(replacements)

# 3. Encode categorical variables
# -----------------------------
label_encoders_1 = {}
label_encoders_1['Crop'] = LabelEncoder()
df2['Crop'] = label_encoders_1['Crop'].fit_transform(df2['Crop'])

# Encode States
label_encoders_1['State'] = LabelEncoder()
df2['State'] = label_encoders_1['State'].fit_transform(df2['State'])

df2.head()

# 4. Features (X) & Targets (y)
# -----------------------------
X_2 = df2[['Year', 'Crop', 'State']]
y_2 = df2[['Cost of Cultivation', 'Implicit Rate']]

# Convert Implicit Rate from per quintal to per metric ton (1 metric ton = 10 quintals)
y_2['Implicit_Rate_per_MT'] = y_2['Implicit Rate'] * 10

# Drop old quintal column if not needed
y_2 = y_2[['Cost of Cultivation', 'Implicit_Rate_per_MT']]

# 5. Train-Test Split
# -----------------------------
X_train_2, X_test_2, y_train_2, y_test_2 = train_test_split(
    X_2, y_2, test_size=0.2, random_state=42, stratify = df2['Crop']
)

# -----------------------------
# 6. Build Model
# -----------------------------
model_2 = MultiOutputRegressor(RandomForestRegressor(
    n_estimators=101, random_state=42
))
model_2.fit(X_train_2, y_train_2)

# Save model
pickle.dump(model_2, open("crop_profitability_model.pkl", "wb"))
pickle.dump(label_encoders_1, open("label_encoders_1.pkl", "wb"))