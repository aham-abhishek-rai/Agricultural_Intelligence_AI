# 1. crop_recommendation.py

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import pickle

# 2. Load or create dataset

df = pd.read_csv("Crop_recommendation.csv")

print(df.head())
print(df.describe())
print(df.info())
print(df.isnull( ).sum())
df['label'] = df['label'].str.capitalize()
print(df.head())
print(df['label'].unique())

# Define a dictionary for replacements
replacement = {'Pigeonpeas': 'Arhar/Tur'}

# Apply the replacements
df['label'] = df['label'].replace(replacement)

print(df.head())
print("Dataset shape:", df.shape)
print(df['label'].unique())

# 3. Prepare data
# --------------------------
X = df[['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall']]
y = df['label']

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 4. Build model
# --------------------------
model = RandomForestClassifier(n_estimators=101, random_state=42)
model.fit(X_train, y_train)

# 7. Save model
# --------------------------
pickle.dump(model, open("crop_recommendation_model.pkl", "wb"))
print("✅ Model saved as crop_recommendation_model.pkl")