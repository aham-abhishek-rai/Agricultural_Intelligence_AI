import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
import pickle

# Load Dataset
# =============================
df1 = pd.read_csv("crop_yield.csv")

df1['Crop'] = df1['Crop'].str.capitalize()

df1 = df1.query('`Crop` != ["Other summer pulses", "Other cereals", "Other oilseeds", "Oilseeds total", "Peas & beans (pulses)", \
                            "Other kharif pulses", "Other  rabi pulses", "Coconut "]')
df1 = df1.query('`Crop_Year` != 2020')
# df1 = df1.query('`Crop_Year` >= 2002')
df1 = df1.query('`Yield` <= 5')

crop_count = df1['Crop'].value_counts()
valid_crop = crop_count[crop_count > 100].index
df1 = df1[df1['Crop'].isin(valid_crop)]

# Define a dictionary for replacements
replacements = {'Arecanut': 'Arecanut/Supari', 'Arhar/tur': 'Arhar/Tur', 'Castor seed': 'Castor Seed', 'Cotton(lint)': 'Cotton', 'Moth': 'Mothbeans', \
                'Dry chillies': 'Dry Chillies', 'Niger seed': 'Niger Seed', 'Rapeseed &mustard': 'Rapeseed & Mustard', 'Sesamum': 'Sesamum/Til', \
                'Small millets': 'Small Millets', 'Sweet potato': 'Sweet Potato', 'Black pepper': 'Black Pepper', 'Moong(green gram)': 'Mungbean',\
                'Cowpea(lobia)': 'Cowpea/Lobia', 'Guar seed': 'Guar Seed'}

# Apply the replacements
df1['Crop'] = df1['Crop'].replace(replacements)

# 10. Encode Categorical Variables
# =============================
label_encoders = {}
for col in ['Crop', 'Season', 'State']:
    le = LabelEncoder()
    df1[col] = le.fit_transform(df1[col])
    label_encoders[col] = le

# 11. Train-Test Split
# =============================
X1 = df1[['Crop', 'Crop_Year', 'State', 'Area', 'Annual_Rainfall', 'Fertilizer', 'Pesticide']] #'Season',
y1 = df1['Yield']

X_train_1, X_test_1, y_train_1, y_test_1 = train_test_split(X1, y1, test_size=0.2, random_state=42, stratify = df1['Crop'])

# =============================
# 12. Model Training
# =============================
model_1 = RandomForestRegressor(n_estimators=101, random_state=42)
model_1.fit(X_train_1, y_train_1)

# 14. Save Model
# =============================
pickle.dump(model_1, open("crop_yield_prediction_model.pkl", "wb"))
pickle.dump(label_encoders, open("label_encoders.pkl", "wb"))

print("✅ Model saved as crop_yield_prediction_model.pkl")