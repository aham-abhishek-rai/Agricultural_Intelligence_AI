from flask import Flask, render_template, request
import numpy as np
import pandas as pd
import pickle

app = Flask(__name__)

# ------------------- Load Models -------------------
crop_recommendation = pickle.load(open("models/crop_recommendation_model.pkl", "rb"))
crop_yield_model = pickle.load(open("models/crop_yield_prediction_model.pkl", "rb"))
yield_encoders = pickle.load(open("models/label_encoders.pkl", "rb"))
crop_profit_model = pickle.load(open("models/crop_profitability_model.pkl", "rb"))
profit_encoders = pickle.load(open("models/label_encoders_1.pkl", "rb"))

# ------------------- Load Data for Ranges -------------------
# Replace with your actual dataset paths
recommend_df = pd.read_csv("models/Crop_recommendation.csv")
yield_df = pd.read_csv("models/crop_yield.csv")
profit_df = pd.read_excel("models/crop_value_cost_data.xlsx")

def get_value_ranges():
    ranges = {
        "Nitrogen (N)": (recommend_df["N"].min(), recommend_df["N"].max()),
        "Phosphorus (P)": (recommend_df["P"].min(), recommend_df["P"].max()),
        "Potassium (K)": (recommend_df["K"].min(), recommend_df["K"].max()),
        "Temperature (°C)": (recommend_df["temperature"].min(), recommend_df["temperature"].max()),
        "Humidity (%)": (recommend_df["humidity"].min(), recommend_df["humidity"].max()),
        "pH": (recommend_df["ph"].min(), recommend_df["ph"].max()),
        "Rainfall (mm)": (
            min(recommend_df["rainfall"].min(), yield_df["Annual_Rainfall"].min()),
            max(recommend_df["rainfall"].max(), yield_df["Annual_Rainfall"].max())
        ),
        "Area (ha)": (yield_df["Area"].min(), yield_df["Area"].max()),
        "Fertilizer (kg)": (yield_df["Fertilizer"].min(), yield_df["Fertilizer"].max()),
        "Pesticide (kg)": (yield_df["Pesticide"].min(), yield_df["Pesticide"].max())
    }
    return ranges

# ------------------- Dropdown Helper -------------------
def get_dropdown_data():
    yield_crops = yield_encoders['Crop'].classes_.tolist()
    yield_states = yield_encoders['State'].classes_.tolist()
    profit_crops = profit_encoders['Crop'].classes_.tolist()
    profit_states = profit_encoders['State'].classes_.tolist()
    common_crops = set(yield_crops) & set(profit_crops)
    common_states = set(yield_states) & set(profit_states)
    years = list(range(1997, 2027))
    return yield_crops, yield_states, profit_crops, profit_states, common_crops, common_states, years

# ------------------- Routes -------------------
@app.route('/')
def home():
    yield_crops, yield_states, profit_crops, profit_states, common_crops, common_states, years = get_dropdown_data()
    return render_template("index.html",
                           yield_crops=yield_crops, yield_states=yield_states,
                           profit_crops=profit_crops, profit_states=profit_states,
                           common_crops=common_crops, common_states=common_states,
                           years=years,
                           ranges=get_value_ranges())

# --------- Crop Recommendation ---------
@app.route('/recommend', methods=['POST'])
def recommend():
    N = float(request.form['N'])
    P = float(request.form['P'])
    K = float(request.form['K'])
    temp = float(request.form['temperature'])
    hum = float(request.form['humidity'])
    ph = float(request.form['ph'])
    rain = float(request.form['rainfall'])
    features = np.array([[N, P, K, temp, hum, ph, rain]])
    prediction = crop_recommendation.predict(features)[0]
    yield_crops, yield_states, profit_crops, profit_states, common_crops, common_states, years = get_dropdown_data()
    return render_template("index.html",
                           recommend_result=prediction,
                           N=N, P=P, K=K, temperature=temp, humidity=hum, ph=ph, rainfall=rain,
                           yield_crops=yield_crops, yield_states=yield_states,
                           profit_crops=profit_crops, profit_states=profit_states,
                           common_crops=common_crops, common_states=common_states, years=years,
                           ranges=get_value_ranges())

# --------- Crop Yield ---------
@app.route('/yield', methods=['POST'])
def yield_prediction():
    crop_name = request.form['crop']
    state_name = request.form['state']
    year = int(request.form['year'])
    area = float(request.form['area'])
    rainfall = float(request.form['rainfall'])
    fertilizer = float(request.form['fertilizer'])
    pesticide = float(request.form['pesticide'])
    crop = yield_encoders['Crop'].transform([crop_name])[0]
    state = yield_encoders['State'].transform([state_name])[0]
    features = pd.DataFrame([{
        'Crop': crop, 'Crop_Year': year, 'State': state,
        'Area': area, 'Annual_Rainfall': rainfall,
        'Fertilizer': fertilizer, 'Pesticide': pesticide
    }])
    prediction = crop_yield_model.predict(features)[0]
    yield_val = round(prediction, 2)
    # Prefill for profitability form
    profit_crop_prefill = crop_name if crop_name in profit_encoders['Crop'].classes_ else None
    profit_state_prefill = state_name if state_name in profit_encoders['State'].classes_ else None
    yield_crops, yield_states, profit_crops, profit_states, common_crops, common_states, years = get_dropdown_data()
    return render_template("index.html",
                           yield_result=yield_val,
                           yield_crop=crop_name, yield_state=state_name, yield_year=year,
                           yield_area=area, yield_rainfall=rainfall,
                           yield_fertilizer=fertilizer, yield_pesticide=pesticide,
                           prefill_yield=yield_val, prefill_area=area, prefill_rainfall=rainfall,
                           prefill_profit_crop=profit_crop_prefill,
                           prefill_profit_state=profit_state_prefill,
                           prefill_profit_year=year,
                           yield_crops=yield_crops, yield_states=yield_states,
                           profit_crops=profit_crops, profit_states=profit_states,
                           common_crops=common_crops, common_states=common_states,
                           years=years,
                           ranges=get_value_ranges())

# --------- Profitability ---------
@app.route('/profit', methods=['POST'])
def profit_prediction():
    crop_name = request.form['crop']
    state_name = request.form['state']
    year = int(request.form['year'])
    area = float(request.form['area'])
    yield_per_ha = float(request.form['yield_per_ha'])
    crop_encoded = profit_encoders['Crop'].transform([crop_name])[0]
    state_encoded = profit_encoders['State'].transform([state_name])[0]
    example = pd.DataFrame({'Year': [year], 'Crop': [crop_encoded], 'State': [state_encoded]})
    cost_per_ha, rate_per_mt = crop_profit_model.predict(example)[0]
    total_yield = yield_per_ha * area
    total_revenue = total_yield * rate_per_mt
    total_cost = cost_per_ha * area
    profit = total_revenue - total_cost
    profit_pct = (profit / total_cost) * 100 if total_cost != 0 else 0
    status = "Profitable ✅" if profit > 0 else "Not Profitable ❌"
    yield_crops, yield_states, profit_crops, profit_states, common_crops, common_states, years = get_dropdown_data()
    return render_template("index.html",
                           profit_status=status,
                           profit_crop=crop_name, profit_state=state_name,
                           profit_year=year, profit_area=area, profit_yield=yield_per_ha,
                           profit_cost=round(cost_per_ha, 2), profit_rate=round(rate_per_mt, 2),
                           profit_revenue=round(total_revenue, 2),
                           profit_total_cost=round(total_cost, 2),
                           profit_value=round(profit, 2), profit_margin=round(profit_pct, 2),
                           yield_crops=yield_crops, yield_states=yield_states,
                           profit_crops=profit_crops, profit_states=profit_states,
                           common_crops=common_crops, common_states=common_states, years=years,
                           ranges=get_value_ranges())

# ------------------- Run -------------------
if __name__ == "__main__":
    app.run(debug=True)